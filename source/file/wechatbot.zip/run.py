# 发送信息
def sendmessage(is_group,name,message):
    if is_group:
        wx.SendKeys('@'+name+'【奶甜】'+message, waitTime=0.3)   
    else:
        wx.SendKeys('【奶甜】'+message, waitTime=0.3)
    wx.SendKeys('{Enter}', waitTime=0.3)
        

import csv  # 引入csv库以读写数据
import random  # 引入random库以发送随机消息
from uiautomation import WindowControl  # 引入uiautomation库中的WindowControl类以进行图像识别和模拟操作
# 加载启用列表
with open('./config/enable_list.csv','r',encoding='utf-8',newline='') as enablelist:
    enalist=[]
    for i in csv.reader(enablelist):
        enalist.append(i)
# 加载关键词列表
with open('./config/keyword.csv','r',encoding='utf-8',newline='') as msglist:
    msg=[]
    for i in csv.reader(msglist):
        msg.append(i)
# 加载随机回复列表
with open('./config/random_reply.csv','r',encoding='utf-8',newline='') as randommsg:
    randommsglist=[]
    for i in csv.reader(randommsg):
        randommsglist.append(i)
with open('./config/random_reply_prefix.csv','r',encoding='utf-8',newline='') as randommsgpre:
    randommsgprelist=[]
    for i in csv.reader(randommsgpre):
        randommsgprelist.append(i) 
# 加载管理员列表
with open('./config/admin.csv','r',encoding='utf-8',newline='') as adminlist:
    admin=[]
    for i in csv.reader(adminlist):
        admin.append(i)
# 绑定微信主窗口
wx=WindowControl(Name='微信',searchDepth=1)
# 切换窗口
wx.ListControl()
wx.SwitchToThisWindow()
# 寻找会话控件绑定
hw=wx.ListControl(Name='会话')

# 死循环接收消息
while True:
    # 右键防止卡bug
    wx.ListControl(Name='会话').RightClick()
    # 从查找未读消息
    we=hw.TextControl(searchDepth=4)
    # 死循环维持，没有超时报错
    while not we.Exists():
        pass
    
    # 存在未读消息
    if we.Name:
        # 点击未读消息
        we.Click(simulateMove=False)
        # 读取最后一条消息
        last_msg=wx.ListControl(Name='消息').GetChildren()[-1].Name
        #查找发送者id及检查是否为群聊与管理员
        last_sender,is_group,is_admin=None,0,0
        for i in range(len(wx.ListControl(Name='消息').GetChildren()[-1].GetChildren()[0].GetChildren())):
            current=wx.ListControl(Name='消息').GetChildren()[-1].GetChildren()[0].GetChildren()[i].Name
            currenttype=wx.ListControl(Name='消息').GetChildren()[-1].GetChildren()[0].GetChildren()[i].LocalizedControlType
            if not current==None and currenttype=="按钮":
                last_sender=current
            if len(wx.ListControl(Name='消息').GetChildren()[-1].GetChildren()[0].GetChildren()[i].GetChildren())>1:
                is_group=1
        for i in admin:
            if i[0]==last_sender:
                is_admin=1
                break
        will_continue=0
        if is_group and '@NekoMilky' in last_msg:
            will_continue=1
        elif not is_group:
            will_continue=1
        if will_continue and not last_sender==None:
            
            # 判断是否为首次使用
            ena,enaid,idfound=2,0,0
            for i in enalist:
                if i[0]==last_sender:
                    ena,idfound=i[1],1
                if not idfound:
                    enaid+=1
            if ena==2:
                enalist.append([last_sender,'0'])
                with open('./config/enable_list.csv','w',encoding='utf-8',newline='') as enablelist:
                    csv.writer(enablelist).writerows(enalist)
            else:     
                
                # 判断关键字
                if '.开启' in last_msg:
                    if enalist[enaid][1]=='0':
                        enalist[enaid][1]='1'
                        with open('./config/enable_list.csv','w',encoding='utf-8',newline='') as enablelist:
                            csv.writer(enablelist).writerows(enalist)
                        reply='成功开启机器人！发送".菜单"以查看指令！'
                        sendmessage(is_group,last_sender,reply)
                    else:
                        reply='你已经开启了机器人！请不要重复操作！'
                        sendmessage(is_group,last_sender,reply)    
                elif enalist[enaid][1]=='1':
                    if '.关闭' in last_msg:
                        enalist[enaid][1]='0'
                        with open('./config/enable_list.csv','w',encoding='utf-8',newline='') as enablelist:
                            csv.writer(enablelist).writerows(enalist)
                        reply='成功关闭机器人！'
                        sendmessage(is_group,last_sender,reply)
                    elif '.菜单' in last_msg:
                        reply='菜单：{Ctrl}{Enter}.菜单->打开菜单{Ctrl}{Enter}.关闭->关闭机器人{Ctrl}{Enter}.开启->开启机器人{Ctrl}{Enter}.关键词.添加 [关键词名] [回复内容]->添加自定义关键词{Ctrl}{Enter}.关键词.删除 [关键词名]->删除指定关键词（需要管理员权限）{Ctrl}{Enter}.管理员.给予 [ID]->给予指定人管理员权限（需要管理员权限）{Ctrl}{Enter}.管理员.剥夺 [ID]->剥夺指定人管理员权限（需要管理员权限）'
                        sendmessage(is_group,last_sender,reply)
                    elif '.关键词.添加' in last_msg:
                        kwadd,kwword,kwreply=[],None,None
                        for i in range(len(last_msg)):
                            if last_msg[i]==' ':
                                kwadd.append(i)
                        if len(kwadd)==2:
                            kwword,kwreply,kwwordfound=last_msg[kwadd[0]+1:kwadd[1]],last_msg[kwadd[1]+1:len(last_msg)],0
                            for i in range(len(msg)):
                                if msg[i][0]==kwword:
                                    kwwordfound=1
                                    break
                            if kwwordfound:
                                reply='执行失败！关键词"'+kwword+'"已经存在！'
                                sendmessage(is_group,last_sender,reply)                                 
                            else:
                                msg.append([kwword,kwreply])
                                with open('./config/keyword.csv','w',encoding='utf-8',newline='') as msglist:
                                    csv.writer(msglist).writerows(msg)                                                        
                                reply='执行成功！成功添加了关键词"'+kwword+'"！回复内容为"'+kwreply+'"！'
                                sendmessage(is_group,last_sender,reply)    
                        else:
                            reply='执行失败！正确用法：.关键词.添加 [关键词名] [回复内容]'
                            sendmessage(is_group,last_sender,reply)  
                    elif '.关键词.删除' in last_msg:
                        if is_admin:
                            kwremove=[]
                            for i in range(len(last_msg)):
                                if last_msg[i]==' ':
                                    kwremove.append(i)
                            if len(kwremove)==1:
                                kwword,kwwordid=last_msg[kwremove[0]+1:len(last_msg)],None
                                for i in range(len(msg)):
                                    if msg[i][0]==kwword:
                                        kwwordid=i
                                        break
                                if kwwordid==None:
                                    reply='执行失败！没有找到关键词"'+kwword+'"！'
                                    sendmessage(is_group,last_sender,reply)                                      
                                else:
                                    del msg[kwwordid]
                                    with open('./config/keyword.csv','w',encoding='utf-8',newline='') as msglist:
                                        csv.writer(msglist).writerows(msg)                                                        
                                    reply='执行成功！删除了关键词"'+kwword+'"！'
                                    sendmessage(is_group,last_sender,reply)    
                            else:
                                reply='执行失败！正确用法：.关键词.删除 [关键词名]'
                                sendmessage(is_group,last_sender,reply)                              
                        else:
                            reply='执行失败！你没有执行权限！'
                            sendmessage(is_group,last_sender,reply) 
                    elif '.管理员.给予' in last_msg:        
                        if is_admin:
                            admingive=[]
                            for i in range(len(last_msg)):
                                if last_msg[i]==' ':
                                    admingive.append(i)
                            if len(admingive)==1:
                                adminname=last_msg[admingive[0]+1:len(last_msg)]
                                admin.append([adminname])
                                with open('./config/admin.csv','w',encoding='utf-8',newline='') as adminlist:
                                    csv.writer(adminlist).writerows(admin)                                                        
                                reply='执行成功！已给予"'+adminname+'"管理员权限！'
                                sendmessage(is_group,last_sender,reply)    
                            else:
                                reply='执行失败！正确用法：.管理员.给予 [ID]'
                                sendmessage(is_group,last_sender,reply)                               
                        else:
                            reply='执行失败！你没有执行权限！'
                            sendmessage(is_group,last_sender,reply)                             
                    elif '.管理员.剥夺' in last_msg:
                        if is_admin:
                            adminremove=[]
                            for i in range(len(last_msg)):
                                if last_msg[i]==' ':
                                    adminremove.append(i)
                            if len(adminremove)==1:
                                adminname,adminid=last_msg[adminremove[0]+1:len(last_msg)],None
                                for i in range(len(admin)):
                                    if admin[i][0]==adminname:
                                        adminid=i
                                        break
                                if adminid==None:
                                    reply='执行失败！没有找到名为"'+adminname+'"的管理员！'
                                    sendmessage(is_group,last_sender,reply)                                      
                                else:
                                    del admin[adminid]
                                    with open('./config/admin.csv','w',encoding='utf-8',newline='') as adminlist:
                                        csv.writer(adminlist).writerows(admin)                                                        
                                    reply='执行成功！已剥夺"'+adminname+'"的管理员权限！'
                                    sendmessage(is_group,last_sender,reply)    
                            else:
                                reply='执行失败！正确用法：.管理员.剥夺 [ID]'
                                sendmessage(is_group,last_sender,reply)                              
                        else:
                            reply='执行失败！你没有执行权限！'
                            sendmessage(is_group,last_sender,reply) 

                    else:
                        msgid,msgidfound=0,0
                        for i in msg:
                            if i[0] in last_msg:
                                msgidfound=1
                                break
                            msgid+=1
                        # 能够匹配到关键词时固定回复
                        if msgidfound:
                            # 发送消息
                            reply=msg[msgid][1]
                            sendmessage(is_group,last_sender,reply)
                        # 没有匹配到关键词时随机回复
                        else:  
                            reply=randommsgprelist[random.randint(1,len(randommsgprelist))-1][0]+' '+randommsglist[random.randint(1,len(randommsglist))-1][0]            
                            sendmessage(is_group,last_sender,reply)
